public interface FrequentRenterPointStrategy {
    int calculatePoints(int daysRented);
}

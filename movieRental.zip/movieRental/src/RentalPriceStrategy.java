// Parent Class for Rental Price
public interface RentalPriceStrategy {
    float calculatePrice(int daysRented);
}

